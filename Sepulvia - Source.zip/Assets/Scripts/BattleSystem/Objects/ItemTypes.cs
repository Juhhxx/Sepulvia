public enum ItemTypes
{
    Immediate,
    LongTerm,
    Equippable,
    Save
}