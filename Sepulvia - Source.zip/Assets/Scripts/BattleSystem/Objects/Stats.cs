public enum Stats
{
    PullStrength,
    Stance,
    StanceGain,
    StanceMax,
    Speed
}