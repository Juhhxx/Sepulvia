public enum Stats
{
    PullStrength,
    Stance,
    StanceGain,
    Speed
}