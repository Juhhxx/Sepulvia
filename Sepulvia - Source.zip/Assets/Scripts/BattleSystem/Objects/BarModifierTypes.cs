public enum BarModifierTypes
{
    Barrier
}