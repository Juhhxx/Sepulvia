public enum EquipmentType
{
    StatModifier,
    MoveModidier
}